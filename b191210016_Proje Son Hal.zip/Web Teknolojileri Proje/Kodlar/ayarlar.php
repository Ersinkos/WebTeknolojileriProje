<?php

$uye = [
    'kullanici_adi' => 'b191210016@ogr.sakarya.edu.tr',
    'sifre' => '123'
];